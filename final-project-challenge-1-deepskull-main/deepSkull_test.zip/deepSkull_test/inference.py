import argparse
import os
import sys
from pathlib import Path
import numpy as np
from PIL import Image
import pandas as pd

import cv2
import torch
import torch.backends.cudnn as cudnn

FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative


from utils.datasets import IMG_FORMATS, VID_FORMATS, LoadImages, LoadStreams
from utils.general import (LOGGER, check_file, check_img_size, check_imshow, check_requirements, colorstr,
                           increment_path, non_max_suppression, print_args, scale_coords, strip_optimizer, xyxy2xywh)
from utils.plots import Annotator, colors, save_one_box
from utils.torch_utils import select_device, time_sync
import utils.resnet as resnet
import torch.nn.functional as F
import torch.nn as nn
from utils.ensemble import compute_points

def get_model(model_name,model_path,device="cuda: 0"):
    """
    model_name: support "resnet18","resnet34","resnet50","resnet101"
    model_path: the path of model weight
                resnet18: "model/3DCNN_resnet18/0.859_47.pth"
                resnet34: "model/3DCNN_resnet34/0.862_26.pth"
                resnet50: "model/3DCNN_resnet50/0.871_59.pth"
                resnet101: "model/3DCNN_resnet101/0.849_60.pth"
    device: the device for inference
    return resnet model
    """
    model = getattr(resnet,model_name)(
                    num_classes=2,
                    sample_size=512,
                    sample_duration=48)
    model.conv1 = nn.Conv3d(1,64,kernel_size=(7, 7, 7), stride=(1, 2, 2), padding=(3, 3, 3), bias=False)
    model.load_state_dict(torch.load(model_path,map_location=device))
    return model
def predict_case(input,model,device="cuda: 0"):
    """
    input: (N, Height, Width) np.ndarray
    model: from get_model(model_name,model_path)
    return 0 or 1 (0 indicates no fracture, 1 indicates fracture detected)
    """
    input = input.astype("float")
    input = (input - input.min())/(input.max()-input.min())
    input = (input - 0.5) * 2.
    input = torch.from_numpy(input)
    input = input.unsqueeze(0).unsqueeze(0)
    input = F.interpolate(input,(model.sample_duration,512,512)).float().to(device)
    model.to(device)
    model.eval()
    with torch.no_grad():
        return int(torch.max(model(input),dim=1)[1].detach().cpu().numpy())

def get_model_points(model_path="model/0.69_yolov5x.pt"):
    # Return the trained model, and model_path is the checkpoint path, default is "model/0.69_yolov5x.pt"
    model = torch.hub.load('ultralytics/yolov5', 'custom', path=model_path)
    return model


def predict_points(input_batch, model_points, device=select_device(device="0")):
    """
    input_batch shape: (N, 512, 512), and N is the number of CT images for one patient.
    The input np.ndarray will go through the preprocessing process and further save to the folder which path is "./datasets/test/images/".
    If you want to make prediction on another patients, delete the "datasets" folder in advance.
    model_points: trained model
    This function return a 3D-list with detected fractracture coordinates
    """
    out = dict()
    if not os.path.isdir("./datasets/"):
        os.mkdir("./datasets/")
    if not os.path.isdir("./datasets/test/"):
        os.mkdir("./datasets/test/")
    if not os.path.isdir("./datasets/test/images"):
        os.mkdir("./datasets/test/images")
    root = "./datasets/test/images/"
    imgsz = [input_batch.shape[1], input_batch.shape[2]]
    for i in range(len(input_batch)):
        img = input_batch[i, :, :] # preprocessing and save the preprocessed image
        img /= 10.
        img = np.where(img < 0, 0, img)
        img = np.where(img > 255, 255, img)
        img = Image.fromarray(img)
        img = img.convert('RGB')
        fn = str(i)
        img.save(root + f"{fn}.jpg") # zero indexed filename, the content of 0.jpg is the first slice .jpg image
    stride, pt = model_points.stride, model_points.pt
    imgsz = check_img_size(imgsz, s=stride)
    dataset = LoadImages(root, img_size=imgsz, stride=stride, auto=pt)
    bs = 1
    vid_path, vid_writer = [None] * bs, [None] * bs
    # model_points.warmup(imgsz=(1, 3, *imgsz), half=None)
    dt, seen = [0.0, 0.0, 0.0], 0
    for path, im, im0s, vid_cap, s in dataset:
        t1 = time_sync()
        im = torch.from_numpy(im).to(device)
        im = im.float()  # uint8 to fp16/32
        im /= 255  # 0 - 255 to 0.0 - 1.0
        if len(im.shape) == 3:
            im = im[None]  # expand for batch dim
        t2 = time_sync()
        dt[0] += t2 - t1 
        visualize = False
        pred = model_points(im, augment=False)
        t3 = time_sync()
        dt[1] += t3 - t2

        # NMS
        pred = non_max_suppression(pred, conf_thres=0.25, iou_thres=0.45, classes=None, max_det=1000)
        dt[2] += time_sync() - t3
        for i, det in enumerate(pred):
            seen += 1
            p, im0, frame = path, im0s.copy(), getattr(dataset, 'frame', 0)
            p = Path(p)
            out[p.name] = []
            if len(det):
                det[:, :4] = scale_coords(im.shape[2:], det[:, :4], im0.shape)
                for *xyxy, conf, cls in reversed(det):
                    xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4))).view(-1).tolist()
                    out[p.name].append([xywh, conf])

    dic = out
    keys = list(dic.keys())
    keys = sorted(keys, key=lambda x:int(str(x).split('.')[0]))
    all_coords = []
    for key in keys:
        slice_coords = []
        for xywh, c in dic[key]:
            x, y, w, h = xywh
            if c > 0:
                coords = [int(x),int(y)]
                slice_coords.append(coords)
        all_coords.append(slice_coords)
            
    return all_coords

def ensemble_case(*pred_case):
    """
    pred_case: an int value from predict_case() 
    return 0 or 1 (0 indicates no fracture, 1 indicates fracture detected)
    e.g. ensemble_case(pred1,pred2,pred3), where pred1 = predict_case(input,model1),...
    """
    if len(pred_case) % 2 == 1:
        vote_thres = len(pred_case) // 2 + 1
    else:
        vote_thres = len(pred_case) //2
    if sum(pred_case) >= vote_thres:
        return 1
    else:
        return 0

def ensemble_coords(*pred_points):
    """
    pred_points: a 3D list from predict_points()
    return an ensembled 3D list
    e.g. ensemble_coords(predict_points(input_batch,model_points1),predict_points(input_batch,model_points2),predict_points(input_batch,model_points3))
    """
    n_preds = len(pred_points)
    n_slices = len(pred_points[0])
    vote_coords = []
    for i in range(n_slices):
        coords = [pred_points[j][i] for j in range(n_preds)]
        ps = []
        for j in range(n_preds):
            ps += compute_points(j,coords)
        ps = list(set(ps))
        for i in range(len(ps)):
            ps[i] = list(ps[i])
        vote_coords.append(ps)
    return vote_coords
        
def merge(pred_case,pred_points):
    """
    pred_case: pred_cases: an int value from predict_case() 
    pred_points: a 3D list from predict_points()
    return: pred_case, pred_points
    """
    if pred_case == 0:
        return 0,[[] for i in range(len(pred_points))]
    else:
        return 1,pred_points
