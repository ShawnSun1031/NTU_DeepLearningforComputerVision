def compute_points(j,coords,t_dis=32):
    if len(coords) % 2 == 0:
        t = len(coords)//2
    else:
        t = len(coords)//2 + 1
    if len(coords[j]) == 0:
        return []
    else:
        comp = list(range(len(coords)))
        comp.remove(j)
        valid_points = []
        for (x,y) in coords[j]:
            count = 1
            for k in comp:
                for (xc,yc) in coords[k]:
                    if abs(x-xc)+abs(y-yc) < t_dis:
                        count += 1
                        break
            if count >= t:
                valid_points.append((x,y))
        return valid_points