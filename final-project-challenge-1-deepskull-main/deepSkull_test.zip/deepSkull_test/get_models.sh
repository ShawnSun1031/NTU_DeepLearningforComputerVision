cd model
wget -O model.zip https://www.dropbox.com/sh/vkhs2ghrzylkwrt/AAAGxMyzkpNAnvwjxGffUqUsa?dl=1 
wget -O 0.66_yolov5s.pt https://www.dropbox.com/s/hqmvwvjeh8mlwr9/0.66_yolov5s.pt?dl=1
wget -O 0.69_yolov5x.pt https://www.dropbox.com/s/54xl4r0cpx68p8x/F1_0.69.pt?dl=1
wget -O 0.61_yolov5s.pt https://www.dropbox.com/s/0yebc9iu3qy58es/best.pt?dl=1
unzip model.zip
rm model.zip
cd ..
