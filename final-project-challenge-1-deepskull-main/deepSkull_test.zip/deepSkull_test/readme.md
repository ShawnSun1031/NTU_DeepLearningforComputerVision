# DLCV Post Work
## Team: deepSkull
> Members: 蔡哲民、宋家齊、林柏勳、孫欽鉉
## How to Download models
under `deepSkull_test/`, run
```
bash get_models.sh
```

## How to Run Inference.py and Reproduce Results
### Case Level Prediction
#### Load Models
```
resnet18 = get_model("resnet18","model/3DCNN_resnet18/0.859_47.pth")
resnet34 = get_model("resnet34","model/3DCNN_resnet34/0.862_26.pth")
resnet50 = get_model("resnet50","model/3DCNN_resnet50/0.871_59.pth")
resnet101 = get_model("resnet101","model/3DCNN_resnet101/0.849_60.pth")
```
#### Predict Case Level and Ensemble
![](https://i.imgur.com/hJKDcZ0.jpg)

1. case level prediction 1
* call `predict_case()` three times by inputing resnet18, resnet34, resnet50
* call `ensemble_case()` by passing the three values from above
2. case level prediction 2
* call `predict_case()` four times by inputing resnet18, resnet34, resnet50, resnet101
* call `ensemble_case()` by passing the four values from above

illustration of case level prediction 1
![](https://i.imgur.com/feSMF0I.jpg)


### Centroid Level Hit Rate
![Pipeline_2](https://i.imgur.com/giVZYfd.jpg)
#### Load Models
```
0.62_yolov5s = get_model(model_path="model/0.62_yolov5s.pt")
0.66_yolov5s = get_model(model_path="model/0.66_yolov5s.pt")
0.69_yolov5x = get_model(model_path="model/0.69_yolov5x.pt")
```

#### Predict Points and Ensemble
* call `predict_model_points()` three times by passing same input_batch and one of three loaded models each time
* call `merge()` three times by passing the three values from above and **case level prediction 1**
* call `ensemble_coords()` by passing three values from above
* call `merge()` by passing the output of `ensemble_coords()` and **case level prediction 2**
### Ensemble Case Level Prediction and Fractracture Points Prediction
![Pipeline_3](https://i.imgur.com/yK2tXIW.png)


