# DLCV Postwork Stage 2
## Team: deepSkull
> Members: 蔡哲民、宋家齊、林柏勳、孫欽鉉
# Download Skull Dataset
```
download the dataset from https://drive.google.com/file/d/1dKWCyios4wyUWmyNP72BFE5dVp2uYXIN/view?usp=sharing
put skull/ under deepSkull_train/
```

## How to Run Training Code
### Case Level Prediction
```
# Change your current directory to case_level/
cd case_level
```
```
python3 train_3dcnn.py --dataset_path ../skull --z_dim 48 --model_name resnet18
python3 train_3dcnn.py --dataset_path ../skull --z_dim 48 --model_name resnet34
python3 train_3dcnn.py --dataset_path ../skull --z_dim 48 --model_name resnet50
python3 train_3dcnn.py --dataset_path ../skull --z_dim 36 --model_name resnet101
```
The code will first randomly split training data into 2:1 and create two torch.utils.data.Dataset objects triainSet and valSet. Then, train the model you have typed in model_name.

### Centroid Level Hit Rate
1. Preprocessing
    The annotation files were created using the given coordinates of fractracture points. You can check those files under `skull_detection/datasets/train/labels/`. If you would like to add new annotation files, make sure the .txt files' filenames correspond to their images' filenames. The format of annotatiton files should look like this:
    ![](https://i.imgur.com/XfcKeor.png)

    1. No annotation files needed for background image
    2. Each row is in `class x_coord y_coord width height format`
    3. x_coord, y_coord, width, height should be normalized from (0--1)
    4. Ground truth bounding box size we used is (16, 16)
    ```
    # change your current directory to skull_detection/
     cd skull_detection
     ```
     Please make sure your current directory is under `skull_detection/`
     ```
     python3 preprocessing.py
     ```
     This step will preprocess raw input data, i.e., .npy images and save it into the assigned folder `skull_detection/datasets/train/images/` or `skull_detection/datasets/val/images/` with `.jpg` format. The structure of `skull_detection/datasets/` folder should look like this:
     ```
     __datasets/
       |                        # Those annotation files are created in advance,
       |                        # not in this step
       |__train/                # trainig split : validation split = 2 : 1
       |  |__images/
       |  |__labels/            # The training set we used consists of whole 
       |                        # validation set and fractracture slices in 
       |__val/                  # the training split
       |  |__images/
       |  |__labels/            # The validation set we used is the validation 
       |                        # split
       |__test/
       |  |__images/
       |  |__labels/
       |
     ```
2. Start Training
    Please make sure your current directory is under `skull_detection/`
    Run
    ```
    cd yolov5
    python3 train.py --img 512 --batch -1 --epoch 120 --data datasets.yaml --weights yolov5x.pt
    ```
    Argparser explanation:
    `--img 512` means that the input image size is 512 X 512
    
    `--batch -1` is the auto batch size, it will automatically find out the largest batch size your hardware is capable of
    
    `epoch` means how many training epoch you want to run, and also notice that 
    
    `train.py` will monitor your model's improvement and may perform early-stopping while training
    
    `--data datasets.yaml` is the customized configuration file under `skull_detection/yolov5/data/` , and it should look like this:
    ```
    path: ../datasets   # dataset root dir
    train: train/images    # train images (relative to 'path')
    val: val/images    # val images (relative to 'path')
    test: test/images   # test images (relative to 'path')

    nc: 1 # Number of classes
    names: ['fractracture'] # label names
    ```
    `--weights yolov5x.pt` means that we are using the **yolov5x.pt** pre-trained weight to start our training, and your output model will also be the yolov5x trained model.
    
    If you want to know more about hyperparameters choice for training, please visit `skull_detection/yolov5/data/hyps/hyp.scratch.yaml` for details.

3. Check Trained Model
    Your best trained model will be automatically saved to `skull_detection/yolov5/runs/train/exp/weights/best.pt`.
    
