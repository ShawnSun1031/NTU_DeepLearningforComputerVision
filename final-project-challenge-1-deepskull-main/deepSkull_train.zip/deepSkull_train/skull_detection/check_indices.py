import numpy as np
train_idx, val_idx = np.load("/home/ubuntu/dlcv_final/final-project-challenge-1-deepskull/split.npy", allow_pickle=True)
print(val_idx)