wget https://evalai.s3.amazonaws.com/media/submission_files/submission_178471/1597d60e-ccdc-4385-b7e2-e8027536324b.csv -O pred/0.62_test.csv
 -O pred/0.62_test.csv
wget https://evalai.s3.amazonaws.com/media/submission_files/submission_178453/752b897e-4024-48f4-8ccc-34c5b0cb8b28.csv -O pred/0.69_test.csv
wget https://evalai.s3.amazonaws.com/media/submission_files/submission_178422/02cd4153-41de-4849-a02e-be8ac4050e42.csv -O pred/0.66_test.csv

