cd model
wget https://www.dropbox.com/sh/vkhs2ghrzylkwrt/AAAGxMyzkpNAnvwjxGffUqUsa?dl=1 -O model.zip
unzip model.zip
rm model.zip
cd ..